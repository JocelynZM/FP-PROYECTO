/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package software_tienda_compus;

import javax.swing.table.DefaultTableModel;


public class Proveedores extends javax.swing.JFrame {
 // Arreglos para almacenar datos de los productos
    public static String[] idProveedor = new String[100];
    public static String[] nombre = new String[100];
    public static String[] nombreEmpresa = new String[100];
    public static String[] contacto = new String[100];
    public static String[] telefono = new String[100];
    public static String[] correo = new String[100];
    public static String[] direccion = new String[100];
    public static int contador = 0;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Proveedores.class.getName());

    
    public Proveedores() {

        initComponents();
                    actualizarTabla();

        btnEliminar.addMouseListener(new java.awt.event.MouseAdapter() {
        @Override
        
        
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            eliminarProveedor();
        }
    });
    }
    public void actualizarTabla() {

      DefaultTableModel modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("ID Proveedor");
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Nombre Empresa");
        modeloTabla.addColumn("Contacto");
        modeloTabla.addColumn("Telefono");
        modeloTabla.addColumn("Correo");
        modeloTabla.addColumn("Direccion");

        for (int i = 0; i < contador; i++) {
            modeloTabla.addRow(new Object[]{
                idProveedor[i],
                nombre[i],
                nombreEmpresa[i],
                contacto[i],
                telefono[i],
                correo[i],
                direccion[i]
            });
        }

        tabla_proveedores.setModel(modeloTabla);
    }
     
    private void eliminarProveedor() {
    int fila = tabla_proveedores.getSelectedRow();

    if (fila == -1) {
        javax.swing.JOptionPane.showMessageDialog(this,
                "Selecciona un proveedor en la tabla para eliminarlo.");
        return;
    }

    String id = tabla_proveedores.getValueAt(fila, 0).toString();

    int confirm = javax.swing.JOptionPane.showConfirmDialog(this,
            "¿Seguro que deseas eliminar el proveedor con ID: " + id + "?",
            "Confirmar eliminación",
            javax.swing.JOptionPane.YES_NO_OPTION);

    if (confirm != javax.swing.JOptionPane.YES_OPTION) {
        return;
    }

    // Eliminar de los arreglos
    for (int i = fila; i < contador - 1; i++) {
        idProveedor[i] = idProveedor[i + 1];
        nombre[i] = nombre[i + 1];
        nombreEmpresa[i] = nombreEmpresa[i + 1];
        contacto[i] = contacto[i + 1];
        telefono[i] = telefono[i + 1];
        correo[i] = correo[i + 1];
        direccion[i] = direccion[i + 1];
    }

    contador--;

    actualizarTabla();

    javax.swing.JOptionPane.showMessageDialog(this, "Proveedor eliminado correctamente.");
}


// ----------------- BOTÓN EDITAR -----------------
    private void editarProveedores() {
        int fila = tabla_proveedores.getSelectedRow();

        if (fila == -1) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    "Selecciona un proveedor para editar.");
            return;
        }

        // MANDAMOS LOS DATOS A LA VENTANA EDITAR
        Proveedores_editar ventana = new Proveedores_editar(
                this,
                idProveedor[fila],
                nombre[fila],
                nombreEmpresa[fila],
                contacto[fila],
                telefono[fila],
                correo[fila],
                direccion[fila],
               
                fila
        );

        ventana.setVisible(true);
        this.dispose();
    }
    
    
    
    
    
    
    
     


   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabla_proveedores = new javax.swing.JTable();
        btnEliminar = new javax.swing.JLabel();
        atras = new javax.swing.JLabel();
        agregar = new javax.swing.JLabel();
        editar = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tabla_proveedores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID PROVEEDOR", "NOMBRE", "NOMBRE_EMPRESA", "CONTACTO", "TELEFONO", "CORREO", "DIRECCION"
            }
        ));
        jScrollPane3.setViewportView(tabla_proveedores);

        jPanel1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 167, 920, 360));

        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/eliminar.png"))); // NOI18N
        jPanel1.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 90, -1, -1));

        atras.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/atras.png"))); // NOI18N
        atras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                atrasMouseClicked(evt);
            }
        });
        jPanel1.add(atras, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        agregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/anadir.png"))); // NOI18N
        agregar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                agregarMouseClicked(evt);
            }
        });
        jPanel1.add(agregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 90, -1, -1));

        editar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/editarIMG.png"))); // NOI18N
        editar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                editarMouseClicked(evt);
            }
        });
        jPanel1.add(editar, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 90, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Fondo.jpg"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 0, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Fondo.jpg"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 921, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void agregarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_agregarMouseClicked
Proveedores_agregar agregar = new Proveedores_agregar(this);
agregar.setVisible(true);
this.dispose(); 



    }//GEN-LAST:event_agregarMouseClicked

    private void atrasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_atrasMouseClicked
       Menu AbrirMenu = new Menu();
            AbrirMenu.setVisible(true);
            this.dispose();
    }//GEN-LAST:event_atrasMouseClicked

    private void editarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editarMouseClicked
        editarProveedores();
    }//GEN-LAST:event_editarMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Proveedores().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel agregar;
    private javax.swing.JLabel atras;
    private javax.swing.JLabel btnEliminar;
    private javax.swing.JLabel editar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable tabla_proveedores;
    // End of variables declaration//GEN-END:variables
}
