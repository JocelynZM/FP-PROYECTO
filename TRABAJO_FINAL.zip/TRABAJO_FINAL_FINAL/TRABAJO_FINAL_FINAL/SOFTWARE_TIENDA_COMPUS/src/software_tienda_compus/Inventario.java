/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package software_tienda_compus;

import javax.swing.table.DefaultTableModel;


public class Inventario extends javax.swing.JFrame {
 // Arreglos para almacenar datos de los productos
    public static String[] idProducto = new String[100];
    public static String[] nombre = new String[100];
    public static String[] categoria = new String[100];
    public static String[] modelo = new String[100];
    public static String[] precioCompra = new String[100];
    public static String[] precioVenta = new String[100];
    public static String[] stock = new String[100];
    public static String[] descripcion = new String[100];
    public static int contador = 0;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Inventario.class.getName());

    
    public Inventario() {
        initComponents();
            actualizarTabla();

        btnEliminar.addMouseListener(new java.awt.event.MouseAdapter() {
        @Override
        
        
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            eliminarProducto();
        }
    });
    }
    
    public void actualizarTabla() {

      DefaultTableModel modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("ID PRODUCTO");
        modeloTabla.addColumn("NOMBRE");
        modeloTabla.addColumn("CATEGORIA");
        modeloTabla.addColumn("MODELO");
        modeloTabla.addColumn("PRECIO COMPRA ");
        modeloTabla.addColumn("PRECIO VENTA");
        modeloTabla.addColumn("STOCK");
        modeloTabla.addColumn("DESCRIPCION");

        for (int i = 0; i < contador; i++) {
            modeloTabla.addRow(new Object[]{
                idProducto[i],
                nombre[i],
                categoria[i],
                modelo[i],
                precioCompra[i],
                precioVenta[i],
                stock[i],
                descripcion[i]
            });
        }

        tabla_productos.setModel(modeloTabla);
    }
     
    
    
    private void eliminarProducto() {
    int fila = tabla_productos.getSelectedRow();

    if (fila == -1) {
        javax.swing.JOptionPane.showMessageDialog(this,
                "Selecciona un producto en la tabla para eliminarlo.");
        return;
    }

    String id = tabla_productos.getValueAt(fila, 0).toString();

    int confirm = javax.swing.JOptionPane.showConfirmDialog(this,
            "¿Seguro que deseas eliminar el producto con ID: " + id + "?",
            "Confirmar eliminación",
            javax.swing.JOptionPane.YES_NO_OPTION);

    if (confirm != javax.swing.JOptionPane.YES_OPTION) {
        return;
    }

    // Eliminar de los arreglos
    for (int i = fila; i < contador - 1; i++) {
        idProducto[i] = idProducto[i + 1];
        nombre[i] = nombre[i + 1];
        categoria[i] = categoria[i + 1];
        modelo[i] = modelo[i + 1];
        precioCompra[i] = precioCompra[i + 1];
        precioVenta[i] = precioVenta[i + 1];
        stock[i] = stock[i + 1];
        descripcion[i] = descripcion[i + 1];
    }

    contador--;

    actualizarTabla();

    javax.swing.JOptionPane.showMessageDialog(this, "Producto eliminado correctamente.");
}

// ----------------- BOTÓN EDITAR -----------------
    private void editarProducto() {
        int fila = tabla_productos.getSelectedRow();

        if (fila == -1) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    "Selecciona un producto para editar.");
            return;
        }

        // MANDAMOS LOS DATOS A LA VENTANA EDITAR
        Inventario_editar ventana = new Inventario_editar(
                this,
                idProducto[fila],
                nombre[fila],
                categoria[fila],
                modelo[fila],
                precioCompra[fila],
                precioVenta[fila],
                stock[fila],
                descripcion[fila],
                fila
        );

        ventana.setVisible(true);
        this.dispose();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabla_productos = new javax.swing.JTable();
        btnEliminar = new javax.swing.JLabel();
        agregar = new javax.swing.JLabel();
        editar = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        atras = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tabla_productos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID PRODUCTO", "NOMBRE", "CATEGORIA", "MODELO", "PRECIO COMPRA", "PRECIO VENTA", "STOCK", "DESCRIPCIÓN"
            }
        ));
        jScrollPane3.setViewportView(tabla_productos);

        jPanel1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 167, 920, 360));

        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/eliminar.png"))); // NOI18N
        jPanel1.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 90, -1, -1));

        agregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/anadir.png"))); // NOI18N
        agregar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                agregarMouseClicked(evt);
            }
        });
        jPanel1.add(agregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 90, -1, -1));

        editar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/editarIMG.png"))); // NOI18N
        editar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                editarMouseClicked(evt);
            }
        });
        jPanel1.add(editar, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 90, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Fondo.jpg"))); // NOI18N
        jLabel2.setText("jLabel1");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 0, 300, -1));

        atras.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/atras.png"))); // NOI18N
        atras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                atrasMouseClicked(evt);
            }
        });
        jPanel1.add(atras, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Fondo.jpg"))); // NOI18N
        jLabel4.setText("jLabel1");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel1.setText("jLabel1");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 40, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void agregarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_agregarMouseClicked
Inventario_agregar agregar = new Inventario_agregar(this);
agregar.setVisible(true);
this.dispose(); 



    }//GEN-LAST:event_agregarMouseClicked

    private void editarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editarMouseClicked
                                  
    editarProducto();

    }//GEN-LAST:event_editarMouseClicked

    private void atrasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_atrasMouseClicked
 Menu AbrirMenu = new Menu();
            AbrirMenu.setVisible(true);
            this.dispose();    }//GEN-LAST:event_atrasMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Inventario().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel agregar;
    private javax.swing.JLabel atras;
    private javax.swing.JLabel btnEliminar;
    private javax.swing.JLabel editar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable tabla_productos;
    // End of variables declaration//GEN-END:variables
}
