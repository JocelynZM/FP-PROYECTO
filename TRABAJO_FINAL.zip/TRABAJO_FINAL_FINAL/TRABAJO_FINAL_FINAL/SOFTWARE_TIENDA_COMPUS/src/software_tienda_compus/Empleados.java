/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package software_tienda_compus;

import javax.swing.table.DefaultTableModel;


public class Empleados extends javax.swing.JFrame {
 // Arreglos para almacenar datos de los productos
    public static String[] idEmpleado = new String[100];
    public static String[] nombre = new String[100];
    public static String[] apellido = new String[100];
    public static String[] puesto = new String[100];
    public static String[] telefono = new String[100];
    public static String[] correo = new String[100];
    public static String[] direccion = new String[100];
    public static String[] salario = new String[100];
    public static int contador = 0;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Empleados.class.getName());

    
   public Empleados() {
    initComponents();
    
    // IMPORTANTE: cargar datos al abrir la ventana
    actualizarTabla();
    
    btnEliminar.addMouseListener(new java.awt.event.MouseAdapter() {
        @Override
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            eliminarEmpleados();
        }
    });

    }
    
    public void actualizarTabla() {

      DefaultTableModel modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("ID EMPLEADO");
        modeloTabla.addColumn("NOMBRE");
        modeloTabla.addColumn("APELLIDO");
        modeloTabla.addColumn("PUESTO");
        modeloTabla.addColumn("TELEFONO");
        modeloTabla.addColumn("CORREO");
        modeloTabla.addColumn("DIRECCION");
        modeloTabla.addColumn("SALARIO");

        for (int i = 0; i < contador; i++) {
            modeloTabla.addRow(new Object[]{
                idEmpleado[i],
                nombre[i],
                apellido[i],
                puesto[i],
                telefono[i],
                correo[i],
                direccion[i],
                salario[i]
            });
        }

        tablaEmpleados.setModel(modeloTabla);
    }
     
    
    
    private void eliminarEmpleados() {
    int fila = tablaEmpleados.getSelectedRow();

    if (fila == -1) {
        javax.swing.JOptionPane.showMessageDialog(this,
                "Selecciona un empleado en la tabla para eliminarlo.");
        return;
    }

    String id = tablaEmpleados.getValueAt(fila, 0).toString();

    int confirm = javax.swing.JOptionPane.showConfirmDialog(this,
            "¿Seguro que deseas eliminar el empleado con ID: " + id + "?",
            "Confirmar eliminación",
            javax.swing.JOptionPane.YES_NO_OPTION);

    if (confirm != javax.swing.JOptionPane.YES_OPTION) {
        return;
    }

    // Eliminar de los arreglos
    for (int i = fila; i < contador - 1; i++) {
        idEmpleado[i] = idEmpleado[i + 1];
        nombre[i] = nombre[i + 1];
        apellido[i] = apellido[i + 1];
        puesto[i] = puesto[i + 1];
        telefono[i] = telefono[i + 1];
        correo[i] = correo[i + 1];
        direccion[i] = direccion[i + 1];
        salario[i] = salario[i + 1];
    }

    contador--;

    actualizarTabla();

    javax.swing.JOptionPane.showMessageDialog(this, "Empleado eliminado correctamente.");
}


    
    
    // ----------------- BOTÓN EDITAR -----------------
    private void editarEmpleados() {
        int fila = tablaEmpleados.getSelectedRow();

        if (fila == -1) {
            javax.swing.JOptionPane.showMessageDialog(this,
                    "Selecciona un empleado para editar.");
            return;
        }

        // MANDAMOS LOS DATOS A LA VENTANA EDITAR
        Empleado_editar ventana = new Empleado_editar(
                this,
                idEmpleado[fila],
                nombre[fila],
                apellido[fila],
                puesto[fila],
                telefono[fila],
                correo[fila],
                direccion[fila],
                salario[fila],
                fila
        );

        ventana.setVisible(true);
        this.dispose();
    }
    
    
    
    
     


   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tablaEmpleados = new javax.swing.JTable();
        btnEliminar = new javax.swing.JLabel();
        atras = new javax.swing.JLabel();
        agregar = new javax.swing.JLabel();
        editar = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tablaEmpleados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID EMPLEADO", "NOMBRE", "APELLIDO", "PUESTO", "TELEFONO", "CORREO", "DIRECCION", "SALARIO"
            }
        ));
        jScrollPane3.setViewportView(tablaEmpleados);

        jPanel1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 167, 930, 360));

        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/eliminar.png"))); // NOI18N
        jPanel1.add(btnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 90, -1, -1));

        atras.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/atras.png"))); // NOI18N
        atras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                atrasMouseClicked(evt);
            }
        });
        jPanel1.add(atras, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        agregar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/anadir.png"))); // NOI18N
        agregar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                agregarMouseClicked(evt);
            }
        });
        jPanel1.add(agregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 90, -1, -1));

        editar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/editarIMG.png"))); // NOI18N
        editar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                editarMouseClicked(evt);
            }
        });
        jPanel1.add(editar, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 90, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Fondo.jpg"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 0, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/IMAGENES/Fondo.jpg"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 928, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void agregarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_agregarMouseClicked
Empleado_agregar agregar = new Empleado_agregar(this);
agregar.setVisible(true);
this.dispose(); 



    }//GEN-LAST:event_agregarMouseClicked

    private void atrasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_atrasMouseClicked
         Menu AbrirMenu = new Menu();
            AbrirMenu.setVisible(true);
            this.dispose();
    }//GEN-LAST:event_atrasMouseClicked

    private void editarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editarMouseClicked
           editarEmpleados();

    }//GEN-LAST:event_editarMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Empleados().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel agregar;
    private javax.swing.JLabel atras;
    private javax.swing.JLabel btnEliminar;
    private javax.swing.JLabel editar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable tablaEmpleados;
    // End of variables declaration//GEN-END:variables
}
